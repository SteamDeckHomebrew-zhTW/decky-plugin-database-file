# Decky System Toolbox Plugin

A Decky plugin for the Steam Deck containing various settings useful for tinkerers

## Features

### Services
- SSH Server toggle
- CEF Debugger forwarding toggle

### Settings
- Transparent Huge pages toggle

## Screenshot

![](/assets/screenshot.jpg)
